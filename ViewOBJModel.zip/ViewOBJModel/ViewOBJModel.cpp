﻿// ViewOBJModel.cpp : This file contains the 'main' function. Program execution begins and ends there.

#include <Windows.h>
#include <locale>
#include <codecvt>
#include <vector>

#include <stdlib.h> // necesare pentru citirea shader-elor
#include <stdio.h>
#include <math.h> 

#include <GL/glew.h>

#include <GLM.hpp>
#include <gtc/matrix_transform.hpp>
#include <gtc/type_ptr.hpp>

#include <glfw3.h>

#include <iostream>
#include <fstream>
#include <sstream>
#include "Shader.h"
#include "Model.h"
#include "FlyingCube.h"
#include <stb_image.h>

#pragma comment (lib, "glfw3dll.lib")
#pragma comment (lib, "glew32.lib")
#pragma comment (lib, "OpenGL32.lib")

// settings
const unsigned int SCR_WIDTH = 800;
const unsigned int SCR_HEIGHT = 600;
bool isInteriorView = false; // Flag for interior view mode

enum ECameraMovementType
{
	UNKNOWN,
	FORWARD,
	BACKWARD,
	LEFT,
	RIGHT,
	UP,
	DOWN
};

class Camera
{
private:
	// Default camera values

	const float zNEAR = 0.1f;
	const float zFAR = 500.f;
	const float YAW = -90.0f;
	const float PITCH = 0.0f;
	const float FOV = 45.0f;
	glm::vec3 startPosition;

public:
	Camera(const int width, const int height, const glm::vec3& position)
	{
		startPosition = position;
		Set(width, height, position);
	}

	void Set(const int width, const int height, const glm::vec3& position)
	{
		this->isPerspective = true;
		this->yaw = YAW;
		this->pitch = PITCH;

		this->FoVy = FOV;
		this->width = width;
		this->height = height;
		this->zNear = zNEAR;
		this->zFar = zFAR;

		this->worldUp = glm::vec3(0, 1, 0);
		this->position = position;

		lastX = width / 2.0f;
		lastY = height / 2.0f;
		bFirstMouseMove = true;

		UpdateCameraVectors();
	}

	void Reset(const int width, const int height)
	{
		Set(width, height, startPosition);
	}

	void Reshape(int windowWidth, int windowHeight)
	{
		width = windowWidth;
		height = windowHeight;

		// define the viewport transformation
		glViewport(0, 0, windowWidth, windowHeight);
	}

	const glm::mat4 GetViewMatrix() const
	{
		// Returns the View Matrix
		return glm::lookAt(position, position + forward, up);
	}

	const glm::vec3 GetPosition() const
	{
		return position;
	}

	const glm::mat4 GetProjectionMatrix() const
	{
		glm::mat4 Proj = glm::mat4(1);
		if (isPerspective) {
			float aspectRatio = ((float)(width)) / height;
			Proj = glm::perspective(glm::radians(FoVy), aspectRatio, zNear, zFar);
		}
		else {
			float scaleFactor = 2000.f;
			Proj = glm::ortho<float>(
				-width / scaleFactor, width / scaleFactor,
				-height / scaleFactor, height / scaleFactor, -zFar, zFar);
		}
		return Proj;
	}

	void ProcessKeyboard(ECameraMovementType direction, float deltaTime)
	{
		float velocity = (float)(cameraSpeedFactor * deltaTime);
		switch (direction) {
		case ECameraMovementType::FORWARD:
			position += forward * velocity;
			break;
		case ECameraMovementType::BACKWARD:
			position -= forward * velocity;
			break;
		case ECameraMovementType::LEFT:
			position -= right * velocity;
			break;
		case ECameraMovementType::RIGHT:
			position += right * velocity;
			break;
		case ECameraMovementType::UP:
			position += up * velocity;
			break;
		case ECameraMovementType::DOWN:
			position -= up * velocity;
			break;
		}
	}

	void MouseControl(float xPos, float yPos)
	{
		if (bFirstMouseMove) {
			lastX = xPos;
			lastY = yPos;
			bFirstMouseMove = false;
		}

		float xChange = xPos - lastX;
		float yChange = lastY - yPos;
		lastX = xPos;
		lastY = yPos;

		if (fabs(xChange) <= 1e-6 && fabs(yChange) <= 1e-6) {
			return;
		}
		xChange *= mouseSensitivity;
		yChange *= mouseSensitivity;

		ProcessMouseMovement(xChange, yChange);
	}

	void ProcessMouseScroll(float yOffset)
	{
		if (FoVy >= 1.0f && FoVy <= 90.0f) {
			FoVy -= yOffset;
		}
		if (FoVy <= 1.0f)
			FoVy = 1.0f;
		if (FoVy >= 90.0f)
			FoVy = 90.0f;
	}

private:
	void ProcessMouseMovement(float xOffset, float yOffset, bool constrainPitch = true)
	{
		yaw += xOffset;
		pitch += yOffset;

		//std::cout << "yaw = " << yaw << std::endl;
		//std::cout << "pitch = " << pitch << std::endl;

		// Avem grijã sã nu ne dãm peste cap
		if (constrainPitch) {
			if (pitch > 89.0f)
				pitch = 89.0f;
			if (pitch < -89.0f)
				pitch = -89.0f;
		}

		// Se modificã vectorii camerei pe baza unghiurilor Euler
		UpdateCameraVectors();
	}

	void UpdateCameraVectors()
	{
		// Calculate the new forward vector
		this->forward.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
		this->forward.y = sin(glm::radians(pitch));
		this->forward.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));
		this->forward = glm::normalize(this->forward);
		// Also re-calculate the Right and Up vector
		right = glm::normalize(glm::cross(forward, worldUp));  // Normalize the vectors, because their length gets closer to 0 the more you look up or down which results in slower movement.
		up = glm::normalize(glm::cross(right, forward));
	}

protected:
	const float cameraSpeedFactor = 100.0f;
	const float mouseSensitivity = 0.05f;

	// Perspective properties
	float zNear;
	float zFar;
	float FoVy;
	int width;
	int height;
	bool isPerspective;

	glm::vec3 position;
	glm::vec3 forward;
	glm::vec3 right;
	glm::vec3 up;
	glm::vec3 worldUp;

	// Euler Angles
	float yaw;
	float pitch;

	bool bFirstMouseMove = true;
	float lastX = 0.f, lastY = 0.f;
};

class FollowCamera : public Camera
{
public:
	FollowCamera(const int width, const int height, const glm::vec3& position)
		: Camera(width, height, position) {
	}

	void Update(const glm::vec3& planePosition, float yaw, float pitch)
	{
		// Calculează direcția înainte a avionului
		glm::vec3 planeForward;
		planeForward.x = sin(glm::radians(yaw)) * cos(glm::radians(pitch));
		planeForward.y = sin(glm::radians(pitch));
		planeForward.z = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
		planeForward = glm::normalize(planeForward);

		// Poziționează camera în spatele avionului (folosind +planeForward pentru poziția pe axa Z)
		glm::vec3 cameraOffset = planeForward * 5.0f; // Offset pe direcția inversă a avionului
		position = planePosition + cameraOffset;

		// Camera trebuie să privească avionul
		forward = glm::normalize(planePosition - position);

		// Vector lateral și vertical
		right = glm::normalize(glm::cross(forward, worldUp));
		up = glm::normalize(glm::cross(right, forward));

	}

};

GLuint ProjMatrixLocation, ViewMatrixLocation, WorldMatrixLocation;
Camera* pCamera = nullptr;
FollowCamera* pFollowCamera = nullptr;
bool useFollowCamera = false;

float skyboxVertices[] = {
	// positions          
	-1.0f,  1.0f, -1.0f,
	-1.0f, -1.0f, -1.0f,
	 1.0f, -1.0f, -1.0f,
	 1.0f, -1.0f, -1.0f,
	 1.0f,  1.0f, -1.0f,
	-1.0f,  1.0f, -1.0f,

	-1.0f, -1.0f,  1.0f,
	-1.0f, -1.0f, -1.0f,
	-1.0f,  1.0f, -1.0f,
	-1.0f,  1.0f, -1.0f,
	-1.0f,  1.0f,  1.0f,
	-1.0f, -1.0f,  1.0f,

	 1.0f, -1.0f, -1.0f,
	 1.0f, -1.0f,  1.0f,
	 1.0f,  1.0f,  1.0f,
	 1.0f,  1.0f,  1.0f,
	 1.0f,  1.0f, -1.0f,
	 1.0f, -1.0f, -1.0f,

	-1.0f, -1.0f,  1.0f,
	-1.0f,  1.0f,  1.0f,
	 1.0f,  1.0f,  1.0f,
	 1.0f,  1.0f,  1.0f,
	 1.0f, -1.0f,  1.0f,
	-1.0f, -1.0f,  1.0f,

	-1.0f,  1.0f, -1.0f,
	 1.0f,  1.0f, -1.0f,
	 1.0f,  1.0f,  1.0f,
	 1.0f,  1.0f,  1.0f,
	-1.0f,  1.0f,  1.0f,
	-1.0f,  1.0f, -1.0f,

	-1.0f, -1.0f, -1.0f,
	-1.0f, -1.0f,  1.0f,
	 1.0f, -1.0f, -1.0f,
	 1.0f, -1.0f, -1.0f,
	-1.0f, -1.0f,  1.0f,
	 1.0f, -1.0f,  1.0f
};


void Cleanup()
{
	delete pCamera;
	//delete pFollowCamera;
}

void framebuffer_size_callback(GLFWwindow* window, int width, int height);
void mouse_callback(GLFWwindow* window, double xpos, double ypos);
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset);

// timing
double deltaTime = 0.0f;	// time between current frame and last frame
double lastFrame = 0.0f;
glm::vec3 planePosition(0.0f, 0.3f, 0.0f);
float movementSpeed = 0.05f;
float planeSpeed = 0.0f;
float maxPlaneSpeed = 30.0f;
float rotationSpeed = 5.0f;
float pitchPlane = 0.0f; // Tilt forward/backward
float rollPlane = 0.0f;  // Tilt left/right
float yawPlane = 0.0f;   // Rotate left/right

void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
	if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
	{
		planeSpeed = glm::clamp(planeSpeed + 5.0f, 0.0f, maxPlaneSpeed);
	}

	if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
	{
		planeSpeed = glm::clamp(planeSpeed - 5.0f, 0.0f, maxPlaneSpeed);
	}

	if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS) {
		// Rotim avionul spre stânga
		yawPlane += 1.0f;

		rollPlane = glm::clamp(rollPlane + 3.0f, -70.0f, 70.0f);

		// Calculăm direcția înainte a avionului
		glm::vec3 planeForward;
		planeForward.x = -sin(glm::radians(yawPlane));
		planeForward.z = -cos(glm::radians(yawPlane));
		planeForward.y = 0.0f;

		// Deplasăm avionul înainte
		planePosition += planeForward * movementSpeed;
	}

	if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS) {

		yawPlane -= 1.0f;

		rollPlane = glm::clamp(rollPlane - 3.0f, -70.0f, 70.0f);


		glm::vec3 planeForward;
		planeForward.x = -sin(glm::radians(yawPlane));
		planeForward.z = -cos(glm::radians(yawPlane));
		planeForward.y = 0.0f;

		planePosition += planeForward * movementSpeed;
	}


	if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS) {
		// Înclinăm avionul spre cer (creștem pitchPlane)
		pitchPlane = glm::clamp(pitchPlane - 2.0f, -45.0f, 45.0f); // Inversăm semnul pentru urcare

		// Calculăm direcția pe Y (doar pitch este afectat)
		glm::vec3 planeForward;
		planeForward.x = 0.0f; // Fără mișcare pe X
		planeForward.z = 0.0f; // Fără mișcare pe Z
		planeForward.y = -sin(glm::radians(pitchPlane)); // Urcare corectă pe Y

		// Deplasăm avionul pe Y
		planePosition += planeForward * movementSpeed;
	}


	if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS) {
		// Înclinăm avionul spre pământ (scădem pitchPlane)
		pitchPlane = glm::clamp(pitchPlane + 1.0f, -45.0f, 45.0f); // Inversăm semnul pentru coborâre

		// Calculăm direcția pe Y (doar pitch este afectat)
		glm::vec3 planeForward;
		planeForward.x = 0.0f; // Fără mișcare pe X
		planeForward.z = 0.0f; // Fără mișcare pe Z
		planeForward.y = -sin(glm::radians(pitchPlane)); // Coborâre corectă pe Y

		// Deplasăm avionul pe Y
		planePosition += planeForward * movementSpeed;
	}

	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(window, true);

	if (glfwGetKey(window, GLFW_KEY_UP) == GLFW_PRESS)
		pCamera->ProcessKeyboard(UP, (float)deltaTime);
	if (glfwGetKey(window, GLFW_KEY_DOWN) == GLFW_PRESS)
		pCamera->ProcessKeyboard(DOWN, (float)deltaTime);
	if (glfwGetKey(window, GLFW_KEY_LEFT) == GLFW_PRESS)
		pCamera->ProcessKeyboard(LEFT, (float)deltaTime);
	if (glfwGetKey(window, GLFW_KEY_RIGHT) == GLFW_PRESS)
		pCamera->ProcessKeyboard(RIGHT, (float)deltaTime);
	if (glfwGetKey(window, GLFW_KEY_PAGE_UP) == GLFW_PRESS)
		pCamera->ProcessKeyboard(FORWARD, (float)deltaTime);
	if (glfwGetKey(window, GLFW_KEY_PAGE_DOWN) == GLFW_PRESS)
		pCamera->ProcessKeyboard(BACKWARD, (float)deltaTime);

	if (glfwGetKey(window, GLFW_KEY_R) == GLFW_PRESS) {
		int width, height;
		glfwGetWindowSize(window, &width, &height);
		pCamera->Reset(width, height);
	}

	if (glfwGetKey(window, GLFW_KEY_C) == GLFW_PRESS) {
		useFollowCamera = !useFollowCamera;

		if (useFollowCamera)
		{
			pCamera = pFollowCamera;

			// Extragem vectorul forward din matricea de vedere a camerei
			glm::vec3 cameraForward = glm::normalize(glm::vec3(
				-pFollowCamera->GetViewMatrix()[0][2], // x
				-pFollowCamera->GetViewMatrix()[1][2], // y
				-pFollowCamera->GetViewMatrix()[2][2]  // z
			));

			// Actualizăm yaw și pitch ale avionului
			yawPlane = glm::degrees(atan2(cameraForward.z, cameraForward.x));
			pitchPlane = glm::degrees(asin(cameraForward.y));

			planeSpeed = 0.01f; // Resetăm viteza de început
		}
		else
		{
			pCamera = new Camera(SCR_WIDTH, SCR_HEIGHT, glm::vec3(0.0f, 0.0f, 3.0f));
		}
	}
	if (glfwGetKey(window, GLFW_KEY_G) == GLFW_PRESS) {
		isInteriorView = !isInteriorView;

		if (isInteriorView) {
			// Position the camera inside the interior model
			glm::vec3 interiorPosition(0.0f, 2.0f, 0.0f); // Adjust this to match the interior model's position
			pCamera->Set(SCR_WIDTH, SCR_HEIGHT, interiorPosition);
		}
		else {
			// Switch back to the follow camera
			pCamera = useFollowCamera ? pFollowCamera : new Camera(SCR_WIDTH, SCR_HEIGHT, glm::vec3(0.0, 0.0, 3.0));
		}
	}

}

struct GLTFMesh {
	GLuint vao;
	GLuint vbo;
	GLuint ebo;
	size_t indexCount;
};


void generateSphere(std::vector<float>& vertices, std::vector<unsigned int>& indices, float radius, unsigned int sectorCount, unsigned int stackCount)
{
	float x, y, z, xy; // coordonate pe sferă
	float nx, ny, nz;  // normale
	float s, t;        // coordonate textură

	float sectorStep = 2 * glm::pi<float>() / sectorCount;
	float stackStep = glm::pi<float>() / stackCount;
	float sectorAngle, stackAngle;

	// Generare vertecși
	for (unsigned int i = 0; i <= stackCount; ++i) {
		stackAngle = glm::pi<float>() / 2 - i * stackStep; // de la pi/2 la -pi/2
		xy = radius * cosf(stackAngle); // rază * cos(înălțime)
		z = radius * sinf(stackAngle); // poziția pe axa Z

		for (unsigned int j = 0; j <= sectorCount; ++j) {
			sectorAngle = j * sectorStep; // unghiul în planul XY

			// Coordonatele vertecșilor
			x = xy * cosf(sectorAngle);
			y = xy * sinf(sectorAngle);
			vertices.push_back(x);
			vertices.push_back(y);
			vertices.push_back(z);

			// Coordonatele normale
			nx = x / radius;
			ny = y / radius;
			nz = z / radius;
			vertices.push_back(nx);
			vertices.push_back(ny);
			vertices.push_back(nz);

			// Coordonate textură
			s = (float)j / sectorCount;
			t = (float)i / stackCount;
			vertices.push_back(s);
			vertices.push_back(t);
		}
	}

	// Generare indici pentru triunghiuri
	for (unsigned int i = 0; i < stackCount; ++i) {
		unsigned int k1 = i * (sectorCount + 1); // începutul unei benzi
		unsigned int k2 = k1 + sectorCount + 1; // începutul benzii următoare

		for (unsigned int j = 0; j < sectorCount; ++j, ++k1, ++k2) {
			if (i != 0) {
				indices.push_back(k1);
				indices.push_back(k2);
				indices.push_back(k1 + 1);
			}

			if (i != (stackCount - 1)) {
				indices.push_back(k1 + 1);
				indices.push_back(k2);
				indices.push_back(k2 + 1);
			}
		}
	}
}

unsigned int loadCubemap(std::vector<std::string> faces) {
	unsigned int textureID;
	glGenTextures(1, &textureID);
	glBindTexture(GL_TEXTURE_CUBE_MAP, textureID);

	int width, height, nrChannels;
	for (unsigned int i = 0; i < faces.size(); i++) {
		unsigned char* data = stbi_load(faces[i].c_str(), &width, &height, &nrChannels, 0);
		if (data) {
			glTexImage2D(GL_TEXTURE_CUBE_MAP_POSITIVE_X + i, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
			stbi_image_free(data);
		}
		else {
			std::cout << "Failed to load cubemap texture at path: " << faces[i] << std::endl;
			stbi_image_free(data);
		}
	}
	glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_R, GL_CLAMP_TO_EDGE);

	return textureID;
}

std::string WideStringToString(const std::wstring& wstr) {
	if (wstr.empty()) return std::string();
	int size_needed = WideCharToMultiByte(CP_UTF8, 0, &wstr[0], (int)wstr.size(), NULL, 0, NULL, NULL);
	std::string strTo(size_needed, 0);
	WideCharToMultiByte(CP_UTF8, 0, &wstr[0], (int)wstr.size(), &strTo[0], size_needed, NULL, NULL);
	return strTo;
}

int main()
{

	// glfw: initialize and configure
	glfwInit();
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

	// glfw window creation
	GLFWwindow* window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "Proiect Grafica", NULL, NULL);
	if (window == NULL) {
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return -1;
	}

	glfwMakeContextCurrent(window);
	glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
	glfwSetCursorPosCallback(window, mouse_callback);
	glfwSetScrollCallback(window, scroll_callback);
	glfwSetKeyCallback(window, key_callback);

	// tell GLFW to capture our mouse
	//glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	glewInit();

	glEnable(GL_DEPTH_TEST);

	//skybox----
	unsigned int skyboxVAO, skyboxVBO;
	glGenVertexArrays(1, &skyboxVAO);
	glGenBuffers(1, &skyboxVBO);
	glBindVertexArray(skyboxVAO);
	glBindBuffer(GL_ARRAY_BUFFER, skyboxVBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(skyboxVertices), &skyboxVertices, GL_STATIC_DRAW);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
	glBindVertexArray(0);

	std::vector<std::string> faces = {
	"../ViewOBJModel/x64/Debug/Textures/2/TropicalSunnyDay_rt.jpg", // GL_TEXTURE_CUBE_MAP_POSITIVE_X
	"../ViewOBJModel/x64/Debug/Textures/2/TropicalSunnyDay_lf.jpg", // GL_TEXTURE_CUBE_MAP_NEGATIVE_X
	"../ViewOBJModel/x64/Debug/Textures/2/TropicalSunnyDay_up.jpg", // GL_TEXTURE_CUBE_MAP_POSITIVE_Y
	"../ViewOBJModel/x64/Debug/Textures/2/TropicalSunnyDay_dn.jpg", // GL_TEXTURE_CUBE_MAP_NEGATIVE_Y
	"../ViewOBJModel/x64/Debug/Textures/2/TropicalSunnyDay_ft.jpg", // GL_TEXTURE_CUBE_MAP_POSITIVE_Z
	"../ViewOBJModel/x64/Debug/Textures/2/TropicalSunnyDay_ft.jpg"  // GL_TEXTURE_CUBE_MAP_NEGATIVE_Z
	};

	unsigned int cubemapTexture = loadCubemap(faces);
	//--------
	// 
	// set up vertex data (and buffer(s)) and configure vertex attributes

// Funcție pentru a genera o sferă

	std::vector<float> sphereVertices;
	std::vector<unsigned int> sphereIndices;

	float sphereRadius = 5.0f; // Raza sferei
	unsigned int sectorCount = 36; // Număr de secțiuni în jurul axei Y
	unsigned int stackCount = 18; // Număr de secțiuni pe verticală

	// Generăm vertecșii și indicii pentru sferă
	generateSphere(sphereVertices, sphereIndices, sphereRadius, sectorCount, stackCount);

	// Configurăm VAO și VBO pentru sferă
	unsigned int sphereVAO, sphereVBO, sphereEBO;
	glGenVertexArrays(1, &sphereVAO);
	glGenBuffers(1, &sphereVBO);
	glGenBuffers(1, &sphereEBO);

	glBindVertexArray(sphereVAO);

	// Buffer pentru vertecși
	glBindBuffer(GL_ARRAY_BUFFER, sphereVBO);
	glBufferData(GL_ARRAY_BUFFER, sphereVertices.size() * sizeof(float), &sphereVertices[0], GL_STATIC_DRAW);

	// Buffer pentru indici
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, sphereEBO);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sphereIndices.size() * sizeof(unsigned int), &sphereIndices[0], GL_STATIC_DRAW);

	// Configurăm atributele vertecșilor
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0); // Poziții
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float))); // Normale
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float))); // Coordonate textură
	glEnableVertexAttribArray(2);

	glBindVertexArray(0);

	// second, configure the light's VAO (VBO stays the same; the vertices are the same for the light object which is also a 3D cube)
	unsigned int lightVAO;
	glGenVertexArrays(1, &lightVAO);
	glBindVertexArray(lightVAO);

	// note that we update the lamp's position attribute's stride to reflect the updated buffer data
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);

	// Create camera
	pCamera = new Camera(SCR_WIDTH, SCR_HEIGHT, glm::vec3(0.0, 0.0, 3.0));
	pFollowCamera = new FollowCamera(SCR_WIDTH, SCR_HEIGHT, glm::vec3(0.0f, 0.0f, 3.0f));

	glm::vec3 lightPos(0.0f, 2.0f, 1.0f);
	glm::vec3 cubePos(0.0f, 5.0f, 1.0f);
	glm::vec3 helicopterPos(0.0f, 2.f, 1.0f);

	wchar_t buffer[MAX_PATH];
	GetCurrentDirectoryW(MAX_PATH, buffer);

	std::wstring executablePath(buffer);
	std::wstring wscurrentPath = executablePath.substr(0, executablePath.find_last_of(L"\\/"));

	/*std::wstring_convert<std::codecvt_utf8<wchar_t>> converter;
	std::string currentPath = converter.to_bytes(wscurrentPath);*/

	std::string currentPath = WideStringToString(wscurrentPath);
	Shader skyboxShader((currentPath + "\\Shaders\\skybox.vs").c_str(), (currentPath + "\\Shaders\\skybox.fs").c_str());
	Shader lightingShader((currentPath + "\\Shaders\\PhongLight.vs").c_str(), (currentPath + "\\Shaders\\PhongLight.fs").c_str());
	Shader lightingWithTextureShader((currentPath + "\\Shaders\\PhongLightWithTexture.vs").c_str(), (currentPath + "\\Shaders\\PhongLightWithTexture.fs").c_str());
	Shader lampShader((currentPath + "\\Shaders\\Lamp.vs").c_str(), (currentPath + "\\Shaders\\Lamp.fs").c_str());

	std::string grassOBJFileName = (currentPath + "\\Models\\Grass\\grasslawn.obj");
	Model GrassLawn(grassOBJFileName, false);
	glm::mat4 grassModel = glm::scale(glm::mat4(1.0), glm::vec3(50000.f, 1.f, 50000.f));

	std::string helicopterOBJFileName = (currentPath + "\\Models\\Helicopter\\uh60.dae");
	Model Helicopter(helicopterOBJFileName, false);
	glm::mat4 helicopterModel = glm::translate(glm::mat4(1.0), glm::vec3(14.0f, 0.2f, -5.8f));
	helicopterModel = glm::scale(helicopterModel, glm::vec3(0.1f));
	helicopterModel = glm::rotate(helicopterModel, glm::radians(-90.0f), glm::vec3(1.0, 0.0, 0.0));
	helicopterModel = glm::rotate(helicopterModel, glm::radians(180.0f), glm::vec3(0.0, 0.0, 1.0));

	std::string airportOBJFileName = (currentPath + "\\Models\\Airport\\airport.obj");
	Model Airport(airportOBJFileName, false);
	glm::mat4 airportModel = glm::translate(glm::mat4(1.0), glm::vec3(17.5f, 0.0f, -3.2f));
	airportModel = glm::rotate(airportModel, glm::radians(180.0f), glm::vec3(0.0f, 1.0f, 0.0f));
	airportModel = glm::scale(airportModel, glm::vec3(0.01f));

	std::string landingPlaneOBJFileName = (currentPath + "\\Models\\LandingPlane\\LandingPlane.obj");
	Model LandingPlane(landingPlaneOBJFileName, false);
	glm::mat4 planeModel2 = glm::translate(glm::mat4(1.0), glm::vec3(20.0f, 0.2f, -6.3f));
	planeModel2 = glm::rotate(planeModel2, glm::radians(-90.0f), glm::vec3(0.0f, 1.0f, 0.0f));
	planeModel2 = glm::scale(planeModel2, glm::vec3(0.1f));
	glm::mat4 planeModel3 = glm::translate(glm::mat4(1.0), glm::vec3(5.7f, 0.2f, -5.3f));
	planeModel3 = glm::scale(planeModel3, glm::vec3(0.1f));
	glm::mat4 planeModel4 = glm::translate(glm::mat4(1.0), glm::vec3(9.3f, 0.2f, -5.3f));
	planeModel4 = glm::scale(planeModel4, glm::vec3(0.1f));
	glm::mat4 planeModel5 = glm::translate(glm::mat4(1.0), glm::vec3(6.2f, 0.2f, 4.5f));
	planeModel5 = glm::scale(planeModel5, glm::vec3(0.1f));
	planeModel5 = glm::rotate(planeModel5, glm::radians(180.0f), glm::vec3(0.0f, 1.0f, 0.0f));

	std::string mountainOBJFileName = (currentPath + "\\Models\\Mountain\\mountain.obj");
	Model Mountain(mountainOBJFileName, false);
	glm::mat4 mountainModel = glm::translate(glm::mat4(1.0), glm::vec3(150.0f, -20.0f, -150.0f));
	mountainModel = glm::rotate(mountainModel, glm::radians(-45.0f), glm::vec3(0.0f, 1.0f, 0.0f));
	mountainModel = glm::scale(mountainModel, glm::vec3(150.0f));
	glm::mat4 mountainModel2 = glm::translate(glm::mat4(1.0), glm::vec3(-150.0f, -20.0f, 150.0f));
	mountainModel2 = glm::rotate(mountainModel2, glm::radians(135.0f), glm::vec3(0.0f, 1.0f, 0.0f));
	mountainModel2 = glm::scale(mountainModel2, glm::vec3(150.0f));
	glm::mat4 mountainModel3 = glm::translate(glm::mat4(1.0), glm::vec3(150.0f, -20.0f, 150.0f));
	mountainModel3 = glm::rotate(mountainModel3, glm::radians(-135.0f), glm::vec3(0.0f, 1.0f, 0.0f));
	mountainModel3 = glm::scale(mountainModel3, glm::vec3(150.0f));
	glm::mat4 mountainModel4 = glm::translate(glm::mat4(1.0), glm::vec3(-150.0f, -20.0f, -150.0f));
	mountainModel4 = glm::rotate(mountainModel4, glm::radians(45.0f), glm::vec3(0.0f, 1.0f, 0.0f));
	mountainModel4 = glm::scale(mountainModel4, glm::vec3(150.0f));

	std::string towerOBJFileName = (currentPath + "\\Models\\Tower\\tower.obj");
	Model Tower(towerOBJFileName, false);
	glm::mat4 towerModel = glm::translate(glm::mat4(1.0), glm::vec3(10.0f, 0.0f, -10.0f));
	towerModel = glm::rotate(towerModel, glm::radians(90.0f), glm::vec3(0.0f, 1.0f, 0.0f));
	towerModel = glm::scale(towerModel, glm::vec3(0.07f));

	std::string planeOBJFileName = (currentPath + "\\Models\\Plane\\Fighter_jet.obj");
	Model Plane(planeOBJFileName, false);

	std::string insideOBJFileName = (currentPath + "\\Models\\Inside\\inside.obj");
	Model Inside(insideOBJFileName, false);


	// render loop
	while (!glfwWindowShouldClose(window)) {
		// per-frame time logic
		double currentFrame = glfwGetTime();
		deltaTime = currentFrame - lastFrame;
		lastFrame = currentFrame;
		if (isInteriorView) {


			glm::mat4 view = pCamera->GetViewMatrix();
			lightingWithTextureShader.use();
			lightingWithTextureShader.setMat4("view", view);
			lampShader.use();
			lampShader.setMat4("view", view);

			// Ensure the plane position is updated based on camera forward vector
			glm::vec3 cameraForward = glm::normalize(glm::vec3(
				-view[0][2], // Correct forward direction
				-view[1][2],
				-view[2][2]
			));

			// Plane movement logic (if any) for the interior view
			planePosition += cameraForward * planeSpeed * (float)deltaTime;

			// Gradually reset roll and pitch to neutral if no key is pressed
			if (glfwGetKey(window, GLFW_KEY_A) != GLFW_PRESS && glfwGetKey(window, GLFW_KEY_D) != GLFW_PRESS) {
				rollPlane *= 0.93f; // Reduce roll gradually
				if (fabs(rollPlane) < 0.5f) rollPlane = 0.0f;
			}
			if (glfwGetKey(window, GLFW_KEY_Q) != GLFW_PRESS && glfwGetKey(window, GLFW_KEY_E) != GLFW_PRESS) {
				pitchPlane *= 0.93f; // Reduce pitch gradually
				if (fabs(pitchPlane) < 0.5f) pitchPlane = 0.0f;
			}


		}


		else if (useFollowCamera) {
			pFollowCamera->Update(planePosition, yawPlane, pitchPlane);
			glm::mat4 view = pFollowCamera->GetViewMatrix();
			lightingWithTextureShader.use();
			lightingWithTextureShader.setMat4("view", view);
			lampShader.use();
			lampShader.setMat4("view", view);

			// Extragem direcția înainte corectă
			glm::vec3 cameraForward = glm::normalize(glm::vec3(
				-view[0][2], // Inversăm semnul pentru direcția corectă
				-view[1][2],
				-view[2][2]
			));

			// Avionul se deplasează în direcția înainte a camerei
			planePosition += cameraForward * planeSpeed * (float)deltaTime;


			if (glfwGetKey(window, GLFW_KEY_A) != GLFW_PRESS && glfwGetKey(window, GLFW_KEY_D) != GLFW_PRESS) {
				rollPlane *= 0.93f; // Reducem treptat înclinarea
				if (fabs(rollPlane) < 0.5f) rollPlane = 0.0f; // Resetăm complet dacă este aproape de zero
			}
			if (glfwGetKey(window, GLFW_KEY_Q) != GLFW_PRESS && glfwGetKey(window, GLFW_KEY_E) != GLFW_PRESS) {
				pitchPlane *= 0.93f; // Reducem treptat valoarea pitchPlane
				if (fabs(pitchPlane) < 0.5f) pitchPlane = 0.0f; // Resetăm complet dacă este aproape de zero
			}
		}

		glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		// Desenăm skybox-ul
		glDepthFunc(GL_LEQUAL); // Setare pentru a desena corect skybox-ul
		skyboxShader.use();
		glm::mat4 skyboxView = glm::mat4(glm::mat3(pCamera->GetViewMatrix())); // Eliminăm translația
		glm::mat4 gWVP = pCamera->GetProjectionMatrix() * skyboxView;
		skyboxShader.setMat4("gWVP", gWVP);

		glBindVertexArray(skyboxVAO);
		glBindTexture(GL_TEXTURE_CUBE_MAP, cubemapTexture);
		glDrawArrays(GL_TRIANGLES, 0, 36);
		glBindVertexArray(0);
		glDepthFunc(GL_LESS);

		// Desenăm restul scenei
		lightingShader.use();
		lightingShader.SetVec3("objectColor", 1.0f, 1.0f, 0.0f);
		lightingShader.SetVec3("lightColor", 1.0f, 1.0f, 1.0f);
		lightingShader.SetVec3("lightPos", lightPos);
		lightingShader.SetVec3("viewPos", pCamera->GetPosition());

		lightingShader.setMat4("projection", pCamera->GetProjectionMatrix());
		lightingShader.setMat4("view", pCamera->GetViewMatrix());

		glm::vec3 lightDir = glm::normalize(-lightPos); // Direcția inversă a poziției soarelui
		lightingShader.use();
		lightingShader.SetVec3("lightDir", lightDir);  // Transmite direcția luminii
		lightingShader.SetVec3("lightColor", glm::vec3(1.0f, 1.0f, 0.8f)); // Lumina alb-gălbuie
		lightingShader.SetVec3("objectColor", glm::vec3(1.0f, 1.0f, 1.0f)); // Alb implicit
		lightingShader.SetVec3("viewPos", pCamera->GetPosition()); // Poziția camerei

		// Setăm matricele globale de proiecție și vizualizare pentru shader
		lightingWithTextureShader.use();
		lightingWithTextureShader.setMat4("projection", pCamera->GetProjectionMatrix());
		lightingWithTextureShader.setMat4("view", pCamera->GetViewMatrix());

		// Setăm uniformele globale de iluminare
		lightingWithTextureShader.SetVec3("lightDir", glm::normalize(-lightPos)); // Direcția luminii
		lightingWithTextureShader.SetVec3("lightColor", glm::vec3(1.0f, 1.0f, 0.8f)); // Culoarea luminii (alb-gălbui)
		lightingWithTextureShader.SetVec3("viewPos", pCamera->GetPosition()); // Poziția camerei

		//inside
		glm::mat4 insideModel = glm::translate(glm::mat4(1.0), glm::vec3(0.0f, 2.0f, 0.0f));
		insideModel = glm::scale(insideModel, glm::vec3(1.0f));
		insideModel = glm::rotate(insideModel, glm::radians(180.0f), glm::vec3(0.0f, 1.0f, 0.0f));
		lightingWithTextureShader.setMat4("model", insideModel); // Matricea modelului pentru inside
		Inside.Draw(lightingWithTextureShader);

		// Desenăm câmpul de iarbă
		lightingWithTextureShader.setMat4("model", grassModel); // Matricea modelului pentru iarbă
		GrassLawn.Draw(lightingWithTextureShader);

		// Desenăm aeroportul
		lightingWithTextureShader.setMat4("model", airportModel); // Matricea modelului pentru aeroport
		Airport.Draw(lightingWithTextureShader);

		// Desenăm turnul de control
		lightingWithTextureShader.setMat4("model", towerModel); // Matricea modelului pentru turn
		Tower.Draw(lightingWithTextureShader);

		// Desenăm muntele
		lightingWithTextureShader.setMat4("model", mountainModel); // Matricea modelului pentru munte
		Mountain.Draw(lightingWithTextureShader);

		//munte 2
		lightingWithTextureShader.setMat4("model", mountainModel2); // Matricea modelului pentru munte
		Mountain.Draw(lightingWithTextureShader);

		//munte 3
		lightingWithTextureShader.setMat4("model", mountainModel3); // Matricea modelului pentru munte
		Mountain.Draw(lightingWithTextureShader);

		//munte 4
		lightingWithTextureShader.setMat4("model", mountainModel4); // Matricea modelului pentru munte
		Mountain.Draw(lightingWithTextureShader);

		// Desenăm avionul
		glm::mat4 planeModel = glm::translate(glm::mat4(1.0), planePosition);
		planeModel = glm::rotate(planeModel, glm::radians(yawPlane), glm::vec3(0.0f, 1.0f, 0.0f));
		planeModel = glm::rotate(planeModel, glm::radians(-pitchPlane), glm::vec3(1.0f, 0.0f, 0.0f));
		planeModel = glm::rotate(planeModel, glm::radians(rollPlane), glm::vec3(0.0f, 0.0f, 1.0f));
		planeModel = glm::rotate(planeModel, glm::radians(180.0f), glm::vec3(0.0f, 1.0f, 0.0f));
		planeModel = glm::scale(planeModel, glm::vec3(0.1f));
		lightingWithTextureShader.setMat4("model", planeModel); // Matricea modelului pentru avion
		Plane.Draw(lightingWithTextureShader);


		//avion 2
		lightingWithTextureShader.setMat4("model", planeModel2); // Matricea modelului pentru avion
		LandingPlane.Draw(lightingWithTextureShader);

		//avion 3
		lightingWithTextureShader.setMat4("model", planeModel3); // Matricea modelului pentru avion
		LandingPlane.Draw(lightingWithTextureShader);

		//avion 4
		lightingWithTextureShader.setMat4("model", planeModel4); // Matricea modelului pentru avion
		LandingPlane.Draw(lightingWithTextureShader);

		//avion 5
		lightingWithTextureShader.setMat4("model", planeModel5); // Matricea modelului pentru avion
		LandingPlane.Draw(lightingWithTextureShader);

		// Desenăm elicopterul
		lightingWithTextureShader.setMat4("model", helicopterModel); // Matricea modelului pentru elicopter
		Helicopter.Draw(lightingWithTextureShader);


		// also draw the lamp object
		lampShader.use();
		lampShader.setMat4("projection", pCamera->GetProjectionMatrix());
		lampShader.setMat4("view", pCamera->GetViewMatrix());

		// Calculăm poziția și dimensiunea dinamică a soarelui
		float dayLength = 20.0f; // Durata unui ciclu complet (zi + noapte)
		float progress = fmod(currentFrame, dayLength) / dayLength;
		float orbitRadius = 500.0f; // Raza orbitei sferei
		float orbitRadiusY = 300.0f;
		float intensity = 0.0f;
		glm::vec3 lightColor;

		if (progress < 0.5f) {
			// Ziua
			progress *= 2.0f;
			float sunX = -orbitRadius + 2 * orbitRadius * progress; // Mișcare de la -R la R
			float sunY = sin(progress * glm::pi<float>()) * orbitRadiusY;
			lightPos = glm::vec3(sunX, sunY, 0.0f);

			// Intensitatea luminii cu o valoare minimă
			float minIntensity = 0.5f; // Intensitate minimă mai ridicată
			intensity = glm::smoothstep(0.0f, 30.0f, lightPos.y);
			intensity = glm::clamp(intensity, minIntensity, 0.8f);

			// Interpolare între culoarea dimineții/seară și prânz
			glm::vec3 morningColor = glm::vec3(1.0f, 0.5f, 0.1f); // Portocaliu mai viu
			glm::vec3 noonColor = glm::vec3(1.0f, 1.0f, 0.8f);    // Galben la prânz
			lightColor = glm::mix(morningColor, noonColor, glm::clamp(lightPos.y / 30.0f, 0.0f, 1.0f));
		}
		else {
			// Noaptea
			lightPos = glm::vec3(0.0f, -10.0f, 0.0f);
			intensity = 0.0f;
			lightColor = glm::vec3(0.0f, 0.0f, 0.0f); // Fără lumină noaptea
		}

		// Calculăm modelul pentru soare
		glm::mat4 lightModel = glm::translate(glm::mat4(1.0), lightPos);
		lampShader.setMat4("model", lightModel);

		// Ajustăm culoarea luminii cu intensitatea calculată
		glm::vec3 adjustedLightColor = intensity * lightColor;

		// Transmitem culoarea luminii și alte uniforme către shader
		lampShader.SetVec3("lightColor", adjustedLightColor);
		lampShader.setFloat("time", currentFrame);

		// Desenăm soarele
		glBindVertexArray(sphereVAO);
		glDrawElements(GL_TRIANGLES, sphereIndices.size(), GL_UNSIGNED_INT, 0);
		glBindVertexArray(0);

		// glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
		glfwSwapBuffers(window);
		glfwPollEvents();
	}

	Cleanup();

	glDeleteVertexArrays(1, &lightVAO);

	// glfw: terminate, clearing all previously allocated GLFW resources
	glfwTerminate();
	return 0;
}

// glfw: whenever the window size changed (by OS or user resize) this callback function executes
// ---------------------------------------------------------------------------------------------
void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
	// make sure the viewport matches the new window dimensions; note that width and 
	// height will be significantly larger than specified on retina displays.
	pCamera->Reshape(width, height);
}

void mouse_callback(GLFWwindow* window, double xpos, double ypos)
{
	pCamera->MouseControl((float)xpos, (float)ypos);
}

void scroll_callback(GLFWwindow* window, double xoffset, double yOffset)
{
	pCamera->ProcessMouseScroll((float)yOffset);
}